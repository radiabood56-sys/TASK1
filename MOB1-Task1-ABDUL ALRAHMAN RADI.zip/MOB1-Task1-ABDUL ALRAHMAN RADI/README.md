# MOB1 Task 1 — Java + XML

This is the Java/XML version of the five single-screen Android UI exercises:
1. Birthday Card
2. Task Done
3. Quadrant
4. Article
5. Business Card

## Requirements
- Android Studio
- Android SDK Platform 35
- JDK 17 (Android Studio's bundled JDK is recommended)
- Internet access for the first Gradle sync to download the Android Gradle Plugin

## Open
1. Extract this ZIP file.
2. In Android Studio choose **File > Open**.
3. Select the extracted `MOB1-Task1-Java` folder (the folder containing `settings.gradle.kts`).
4. Wait for Gradle Sync to finish.
5. Connect an Android phone or select an emulator, then press Run.

## Notes
- The app source code is Java (`MainActivity.java`).
- Every screen layout is XML in `app/src/main/res/layout`.
- The Light/Dark button is available on the home screen and each exercise screen.
- Image assets from the supplied ZIP are copied into `drawable-nodpi`.
- Replace the sample name and contact details on the Business Card screen with details approved for your assignment before submission.
- Update the repository name to `MOB1-Task1-YourFullName` before publishing to GitHub.
