package com.example.mob1task1;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String PREFS = "mob1_settings";
    private static final String DARK = "dark_mode";
    private String currentPage = "home";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (savedInstanceState != null) currentPage = savedInstanceState.getString("page", "home");
        applySavedTheme();
        super.onCreate(savedInstanceState);
        showPage(currentPage);
    }

    private void applySavedTheme() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        setTheme(prefs.getBoolean(DARK, false) ? R.style.AppThemeDark : R.style.AppTheme);
    }

    private void toggleTheme() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        prefs.edit().putBoolean(DARK, !prefs.getBoolean(DARK, false)).apply();
        recreate();
    }

    private void showPage(String page) {
        currentPage = page;
        int layout;
        switch (page) {
            case "birthday": layout = R.layout.screen_birthday; break;
            case "task": layout = R.layout.screen_task_done; break;
            case "quadrant": layout = R.layout.screen_quadrant; break;
            case "article": layout = R.layout.screen_article; break;
            case "business": layout = R.layout.screen_business_card; break;
            default: layout = R.layout.activity_main; currentPage = "home";
        }
        setContentView(layout);

        Button themeButton = findViewById(R.id.themeButton);
        if (themeButton != null) themeButton.setOnClickListener(v -> toggleTheme());

        if (currentPage.equals("home")) {
            findViewById(R.id.birthdayButton).setOnClickListener(v -> showPage("birthday"));
            findViewById(R.id.taskButton).setOnClickListener(v -> showPage("task"));
            findViewById(R.id.quadrantButton).setOnClickListener(v -> showPage("quadrant"));
            findViewById(R.id.articleButton).setOnClickListener(v -> showPage("article"));
            findViewById(R.id.businessButton).setOnClickListener(v -> showPage("business"));
        } else {
            TextView title = findViewById(R.id.screenTitle);
            if (title != null) {
                String label = page.substring(0, 1).toUpperCase() + page.substring(1);
                if (page.equals("task")) label = "Task Done";
                if (page.equals("business")) label = "Business Card";
                title.setText(label);
            }
            Button back = findViewById(R.id.backButton);
            if (back != null) back.setOnClickListener(v -> showPage("home"));
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("page", currentPage);
        super.onSaveInstanceState(outState);
    }
}
